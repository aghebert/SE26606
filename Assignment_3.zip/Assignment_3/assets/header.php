<?php
/**
 * Created by PhpStorm.
 * User: aaronhebert
 * Date: 10/16/17
 * Time: 8:12 AM
 */

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Assignment 3 - Aaron Hebert</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <nav></nav>
</head>
<body>
<section id="mainpage">
