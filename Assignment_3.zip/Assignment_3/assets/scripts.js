function clearHtml(){
    var doc = document.getElementById("mainpage").innerHTML = "";
    return doc;
}
