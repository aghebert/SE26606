<?php
/**
 * Created by PhpStorm.
 * User: aaronhebert
 * Date: 10/16/17
 * Time: 8:14 AM
 */

?>

</section>
<footer>
    Copyright &copy; <?php echo date('Y'); ?> Aaron Hebert. All rights reserved
</footer>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="assets/scripts.js"></script>
</body>
</html>
